﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SayHello
{
    class Program
    {
        static void Main(string[] args)
        {
            TestModel();
        }

        private static void TestModel()
        {
            using (var Context = new FluentEFChapter01Entities())
            {
                foreach (Recipe r in Context.Recipes)
                {
                    Console.WriteLine(r.Title);
                    Console.WriteLine(r.Headnote);
                }
                Console.WriteLine("Press enter...");
                Console.ReadLine();
            }
        }
    }
}
