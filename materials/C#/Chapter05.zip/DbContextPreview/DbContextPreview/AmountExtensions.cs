﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DbContextPreview
{
    partial class Amount
    {
        void OnMaximumAmountChanged()
        {
            Console.WriteLine("maximum changed");
        }

        string DisplayAmount { get; set; }
    }
}
