﻿// Default code generation is disabled for model 'C:\Users\Public\Documents\Fluent\Fluent EF\Source Code\VS2010\C#\Chapter05\DbContextPreview\DbContextPreview\Recipes.edmx'. 
// To enable default code generation, change the value of the 'Code Generation Strategy' designer
// property to an alternate value. This property is available in the Properties Window when the model is
// open in the designer.