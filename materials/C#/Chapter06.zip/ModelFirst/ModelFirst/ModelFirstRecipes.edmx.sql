
-- --------------------------------------------------
-- Entity Designer DDL Script for SQL Server 2005, 2008, and Azure
-- --------------------------------------------------
-- Date Created: 10/09/2012 11:26:03
-- Generated from EDMX file: C:\Users\Public\Documents\Fluent\Fluent EF\Source Code\VS2010\C#\Chapter06\ModelFirst\ModelFirst\ModelFirstRecipes.edmx
-- --------------------------------------------------

SET QUOTED_IDENTIFIER OFF;
GO
USE [FluentEFChapter06];
GO
IF SCHEMA_ID(N'dbo') IS NULL EXECUTE(N'CREATE SCHEMA [dbo]');
GO

-- --------------------------------------------------
-- Dropping existing FOREIGN KEY constraints
-- --------------------------------------------------


-- --------------------------------------------------
-- Dropping existing tables
-- --------------------------------------------------


-- --------------------------------------------------
-- Creating all tables
-- --------------------------------------------------

-- Creating table 'Recipes'
CREATE TABLE [dbo].[Recipes] (
    [RecipeId] int IDENTITY(1,1) NOT NULL,
    [RecipeName] nvarchar(max)  NULL,
    [Headnote] nvarchar(max)  NULL
);
GO

-- Creating table 'RecipeIngredients'
CREATE TABLE [dbo].[RecipeIngredients] (
    [IngredientId] int IDENTITY(1,1) NOT NULL,
    [RecipeID] int  NOT NULL,
    [Preparation] nvarchar(max)  NULL,
    [Amount] decimal(18,0)  NULL,
    [Unit] nvarchar(max)  NULL
);
GO

-- Creating table 'RecipeSteps'
CREATE TABLE [dbo].[RecipeSteps] (
    [StepNumber] int IDENTITY(1,1) NOT NULL,
    [RecipeID] int  NOT NULL,
    [Text] nvarchar(max)  NULL
);
GO

-- --------------------------------------------------
-- Creating all PRIMARY KEY constraints
-- --------------------------------------------------

-- Creating primary key on [RecipeId] in table 'Recipes'
ALTER TABLE [dbo].[Recipes]
ADD CONSTRAINT [PK_Recipes]
    PRIMARY KEY CLUSTERED ([RecipeId] ASC);
GO

-- Creating primary key on [IngredientId] in table 'RecipeIngredients'
ALTER TABLE [dbo].[RecipeIngredients]
ADD CONSTRAINT [PK_RecipeIngredients]
    PRIMARY KEY CLUSTERED ([IngredientId] ASC);
GO

-- Creating primary key on [StepNumber] in table 'RecipeSteps'
ALTER TABLE [dbo].[RecipeSteps]
ADD CONSTRAINT [PK_RecipeSteps]
    PRIMARY KEY CLUSTERED ([StepNumber] ASC);
GO

-- --------------------------------------------------
-- Creating all FOREIGN KEY constraints
-- --------------------------------------------------

-- --------------------------------------------------
-- Script has ended
-- --------------------------------------------------