﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Entity;
using CodeFirstModel;

namespace CodeFirstDataAccess
{
    public class RecipeContext : DbContext
    {
        public DbSet<Recipe> Recipes { get; set; }

        //public RecipeContext()
        //    : base("CodeFirstRecipes")
        //{ }
    }
}
