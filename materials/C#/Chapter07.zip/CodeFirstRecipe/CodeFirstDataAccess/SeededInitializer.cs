﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Entity;
using CodeFirstModel;

namespace CodeFirstDataAccess
{
    public class SeededInitializer 
        : DropCreateDatabaseAlways<RecipeContext>
    {
        protected override void Seed(RecipeContext context)
        {
            Recipe r = new Recipe();
            r.RecipeName = "Seeded Recipe";
            r.Headnote = "My second recipe";
            context.Recipes.Add(r);

            base.Seed(context);
        }
    }
}
