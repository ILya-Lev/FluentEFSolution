﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Entity;

namespace CFAnnotations
{
    public class CFContext : DbContext
    {
        public DbSet<IngredientAmount> Amounts { get; set; }
    }
}
