﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Entity;

namespace CFAnnotations
{
    class Program
    {
        static void Main(string[] args)
        {
            Database.SetInitializer<CFContext>
                (new DropCreateDatabaseAlways<CFContext>());

            var a = new IngredientAmount();
            a.Amount = 5;
            a.Name = "some ingredient";

            using (var context = new CFContext())
            {
                context.Amounts.Add(a);
                context.SaveChanges();
            }
        }
    }
}
