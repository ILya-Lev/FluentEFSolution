﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Entity;

namespace CFMultipleRelationships
{
    public class MultipleContext : DbContext
    {
        public DbSet<Recipe> Recipes { get; set; }
    }
}
