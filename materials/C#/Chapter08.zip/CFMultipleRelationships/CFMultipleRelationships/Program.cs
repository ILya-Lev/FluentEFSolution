﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Entity;

namespace CFMultipleRelationships
{
    class Program
    {
        static void Main(string[] args)
        {
            Database.SetInitializer<MultipleContext>(new DropCreateDatabaseAlways<MultipleContext>());

            var r = new Recipe();
            r.RecipeName = "My Recipe";
            r.Headnote = "My first recipe";

            using (var context = new MultipleContext())
            {
                context.Recipes.Add(r);
                context.SaveChanges();
            }
        }
    }
}
