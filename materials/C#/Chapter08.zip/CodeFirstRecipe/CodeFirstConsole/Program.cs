﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Entity;
using CodeFirstModel;
using CodeFirstDataAccess;

namespace CodeFirstConsole
{
    class Program
    {
        static void Main(string[] args)
        {
            Database.SetInitializer<RecipeContext>
                (new SeededInitializer());

            var r = new Recipe();
            r.RecipeName = "My Recipe";
            r.Headnote = "My first recipe";

            using (var context = new RecipeContext())
            {
                context.Recipes.Add(r);
                context.SaveChanges();
            }
        }
    }
}
