﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Entity;
using CodeFirstModel;
using System.Data.Entity.ModelConfiguration;

namespace CodeFirstDataAccess
{
    public class RecipeContext : DbContext
    {
        public DbSet<Recipe> Recipes { get; set; }

        protected override void  OnModelCreating(DbModelBuilder modelBuilder)
        {
 	         base.OnModelCreating(modelBuilder);
             modelBuilder.Configurations.Add(new RecipeConfiguration());
             modelBuilder.Ignore<RecipeStep>();
        }
    }

    public class RecipeConfiguration : EntityTypeConfiguration<Recipe>
    {
        public RecipeConfiguration()
        {
            Property(t => t.RecipeName).HasMaxLength(50)
                .IsRequired()
                .HasColumnName("Name");
        }
    }
}
