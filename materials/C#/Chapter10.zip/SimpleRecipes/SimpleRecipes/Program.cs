﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SimpleRecipes
{
    class Program
    {
        static void Main(string[] args)
        {
            using (var context = new FluentEFChapter10Entities())
            {
                //FIRST EXERCISE
                Recipe myRecipe = new Recipe();
                myRecipe.RecipeName = "Denver Omelet";
                context.Recipes.AddObject(myRecipe);

                //SECOND EXERCISE
                Recipe relatedRecipe = new Recipe();
                relatedRecipe.RecipeName = "Related Test";
                RecipeIngredient relatedIngredient = new RecipeIngredient();
                relatedRecipe.RecipeIngredients.Add(relatedIngredient);
                context.Recipes.AddObject(relatedRecipe);

                Recipe childRecipe = new Recipe();
                childRecipe.RecipeName = "Child Test";
                RecipeIngredient childIngredient = new RecipeIngredient();
                childRecipe.RecipeIngredients.Add(childIngredient);
                context.RecipeIngredients.AddObject(childIngredient);

                context.SaveChanges();
            }
        }
    }
}
